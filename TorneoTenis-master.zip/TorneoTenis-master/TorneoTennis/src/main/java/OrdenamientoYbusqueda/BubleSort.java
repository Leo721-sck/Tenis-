
package OrdenamientoYbusqueda;

import torneotennis.entidades.Jugador;


public class BubleSort {
 
    
    public void ordenamientoBurbuja( Jugador jugadores [] ,  String nombre  ){
        
       Jugador  aux ; 
       
        
        
        for( int i =0;  i <  jugadores.length-1; i ++   ){
            for( int j=0; j <jugadores.length -1;  j++){
                
               if (  jugadores[j].getNombre().compareTo(jugadores[j+1].getNombre()) >0) {
                   
                   
                   aux = jugadores[j]; 
                   jugadores[j]=  jugadores[j+1]; 
                   jugadores[j+1]= aux; 
           
                   
               } 
                
                
                
            }
            
            
        } 
            
        
        
        for ( int i=0; i < jugadores.length ; i  ++){
            
            System.out.println("ordenadas " + jugadores[i]);
            
        }
            
            
             
        
    }
    
}
