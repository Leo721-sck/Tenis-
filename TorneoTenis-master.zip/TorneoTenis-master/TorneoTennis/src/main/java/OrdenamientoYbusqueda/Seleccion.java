
package OrdenamientoYbusqueda;

import torneotennis.entidades.Jugador;


public class Seleccion {
    
    
  

    public void seleccion(  Jugador jugadores[] , String nombre ){
        
        int pos ; 
          Jugador aux ; 
        for(int  i =0;  i <  jugadores.length; i++ ) {
         
            pos =i ; 
            
            for(int  j =0; i<jugadores.length-1 ; j  ++) {
                
            if(jugadores[pos].getNombre().compareTo(jugadores[j].getNombre())>0){
           
                  pos=j;
     
            }
            
            if(pos!=i){
                

                aux = jugadores[i];
                jugadores[i]=jugadores[pos];
                jugadores[ i]=aux;

                
                
            }
                
            }
        }
        
           
        for ( int i=0; i < jugadores.length ; i  ++){
            
            System.out.println("ordenadas " + jugadores[i]);
            
        }
            
        
    }
    
}
