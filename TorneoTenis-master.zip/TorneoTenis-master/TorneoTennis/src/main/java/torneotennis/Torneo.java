package torneotennis;


import OrdenamientoYbusqueda.BubleSort;
import OrdenamientoYbusqueda.Seleccion;
import java.util.Scanner;
import torneotennis.entidades.Estadio;
import torneotennis.entidades.Jugador;
import torneotennis.entidades.Partida;
import torneotennis.manejador.controlJugadores;

/**
 *
 * @author angelrg
 */
public class Torneo {

    private Scanner lee = new Scanner(System.in); 
    private controlJugadores contJugadores = new controlJugadores();

    private Scanner scanner = new Scanner(System.in);
    private Jugador[] jugadores;
    private Jugador[] jugadoresDisponibles;
    private Estadio[] estadios;
    private Partida[] partidas;

    
    public void agregarDatos() {

        System.out.println("Cuantos Jugadores desea Ingresar?");
        jugadores = getJugadores();
        jugadoresDisponibles = jugadores;
        imprimirJugadores();
        menu();
        
        
        System.out.println(" ordenamiento" );
        System.out.println(" Escriba el nombre");
        String nombre = lee.nextLine(); 
        
        BubleSort o1 =  new BubleSort ();  
        o1.ordenamientoBurbuja(jugadores, nombre);
        
        
       Seleccion sel1  = new Seleccion();  
       sel1.seleccion(jugadores, nombre);
       
       
      
        
    }

    private void imprimirJugadores() {
        for (Jugador jugador : jugadores) {
            jugador.printMe();
        }
    }

    private Jugador[] getJugadores() {
        System.out.println("Cuantos jugadores Ingresara: ");
        int tamaño = Integer.parseInt(scanner.nextLine());
        Jugador[] jugador = new Jugador[tamaño];

        for (int i = 0; i < jugador.length; i++) {
            System.out.println("Ingrese el Nombre:");
            String nombre = scanner.nextLine();
            System.out.println("Ingrese Punteo: ");
            int edad = Integer.parseInt(scanner.nextLine());

            jugador[i] = new Jugador(nombre, 0, edad);
        }

        return jugador;
    }
    
    
    
    
    
    private void  menu   ()    {
    
        
        
    int seleccion=0; 
    
        do{
            
            System.out.println("Que busqueda desea hacer ?  ");
            
            System.out.println("1. Secuancial (a  base del punteo) ");
            System.out.println("2. Binara  (a base del punteo ) ");
            System.out.println("3, Binara (a base del nombre )");
            seleccion  = lee.nextInt();  // lee las opciones que se eligieron 
            
          switch(seleccion){   
            
              case 1: 
                  
                  buscarJugador();
                  
                  break ; 
                  
                  
              case 2 : 
                  
                     buscarJugador1();
                  break; 
                  
                  
             case 3 : 
                  
                   buscarJugador2(); 
                 
                  
                  break; 
                  
                  
                        
             default: 
                 
                 System.out.println(" Escoga una opcion valida ");
                 break; 
            
            
            
            
          }
            
            
        }while( seleccion >0 || seleccion < 4 );  
        
    
    
    
}
    
    
    
    
    
    
    
    
    
    
    

    private  void  buscarJugador() {
        System.out.println("Ingrese el punteo del Jugador: ");
        int punteo = Integer.parseInt(scanner.nextLine());
        
        String nombre = scanner.nextLine();
        try {
            System.out.println("Secuencial: ");
            Jugador resultadoSecuencial = contJugadores.buscarJugador(jugadores, punteo);
            resultadoSecuencial.printMe();
            
            
        
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }
    
    
    
    
    private  void  buscarJugador1() {
        System.out.println("Ingrese el punteo del Jugador: ");
        int punteo = Integer.parseInt(scanner.nextLine());
        
        String nombre = scanner.nextLine();
        try {
            
            System.out.println("\nBinaria: ");
            Jugador resultado = contJugadores.buscarJugadorBinario(jugadores, punteo);
            resultado.printMe();
            
        
        
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }
    
    
    
    private  void  buscarJugador2() {
       
        System.out.println(" Escriba el nombre ");
        
        String nombre = scanner.nextLine();
        
        try {
            Jugador resultado = contJugadores.buscarBinarioNombre(nombre, jugadores); 
            resultado.printMe();
            
            
        
        
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }
    
    
    
    ///////////////////////////////////////////////////////////////////////////////
    
    
    

}
